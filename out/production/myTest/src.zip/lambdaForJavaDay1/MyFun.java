package lambdaForJavaDay1;

@FunctionalInterface
public interface MyFun {

	public Integer getValue(Integer num);
	
}
