package lambdaForJavaDay2;

public interface MyFun {
	
	default String getName(){
		return "哈哈哈";
	}

}
