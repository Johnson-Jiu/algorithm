package lambdaForJavaDay2;

public class MyClass {
	
	public String getName(){
		return "嘿嘿嘿";
	}

}
